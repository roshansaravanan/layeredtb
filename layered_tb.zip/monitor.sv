class monitor;

  virtual intf vif;
  mailbox mon2scb;

  function new(virtual intf vif,mailbox mon2scb);
    this.vif      = vif;
    this.mon2scb  = mon2scb;
  endfunction

  task main;
    repeat(10)
      begin
        transaction trans;
        trans = new();

        @(posedge vif.clk);
        #1;   // wait for q to update after the clock edge
        trans.d  = vif.d;
        trans.q  = vif.q;
        mon2scb.put(trans);
        trans.display("Monitor");
      end
  endtask

endclass
